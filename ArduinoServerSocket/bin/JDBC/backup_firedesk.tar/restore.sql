--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Firedesk";
--
-- Name: Firedesk; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Firedesk" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Portuguese_Brazil.1252' LC_CTYPE = 'Portuguese_Brazil.1252';


ALTER DATABASE "Firedesk" OWNER TO postgres;

\connect "Firedesk"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: empreendimentos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.empreendimentos (
    id integer NOT NULL,
    cnpj character varying(20) NOT NULL,
    razao_social character varying(100) NOT NULL,
    id_statusregistro integer,
    id_tiposempreendimentos integer,
    buscardados smallint DEFAULT 10,
    atualizarpage smallint DEFAULT 10,
    tempambmax smallint DEFAULT 100,
    tempambmin smallint DEFAULT 0,
    tempambmedidor character varying(1) DEFAULT 'C'::character varying,
    umidambmax smallint DEFAULT 100,
    umidambmin smallint DEFAULT 0,
    emailnotificacao character varying(2000),
    notificar boolean DEFAULT true,
    editado boolean DEFAULT true,
    correntmin smallint DEFAULT 0,
    correntmax smallint DEFAULT 30
);


ALTER TABLE public.empreendimentos OWNER TO postgres;

--
-- Name: empreendimentos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.empreendimentos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.empreendimentos_id_seq OWNER TO postgres;

--
-- Name: empreendimentos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.empreendimentos_id_seq OWNED BY public.empreendimentos.id;


--
-- Name: empreendimentos_usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.empreendimentos_usuarios (
    id integer NOT NULL,
    id_usuario integer,
    id_empreendimentos integer
);


ALTER TABLE public.empreendimentos_usuarios OWNER TO postgres;

--
-- Name: empreendimentos_usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.empreendimentos_usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.empreendimentos_usuarios_id_seq OWNER TO postgres;

--
-- Name: empreendimentos_usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.empreendimentos_usuarios_id_seq OWNED BY public.empreendimentos_usuarios.id;


--
-- Name: log_empreendimentos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.log_empreendimentos (
    id bigint NOT NULL,
    id_empreendimento integer,
    datahorainclusao timestamp without time zone,
    temperatura numeric(10,2),
    umidade smallint
);


ALTER TABLE public.log_empreendimentos OWNER TO postgres;

--
-- Name: log_empreendimentos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.log_empreendimentos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.log_empreendimentos_id_seq OWNER TO postgres;

--
-- Name: log_empreendimentos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.log_empreendimentos_id_seq OWNED BY public.log_empreendimentos.id;


--
-- Name: status_registro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status_registro (
    id integer NOT NULL,
    descricao character varying(25)
);


ALTER TABLE public.status_registro OWNER TO postgres;

--
-- Name: status_registro_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.status_registro_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.status_registro_id_seq OWNER TO postgres;

--
-- Name: status_registro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.status_registro_id_seq OWNED BY public.status_registro.id;


--
-- Name: tipos_empreendimentos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipos_empreendimentos (
    id integer NOT NULL,
    descricao character varying(30)
);


ALTER TABLE public.tipos_empreendimentos OWNER TO postgres;

--
-- Name: tipos_empreendimentos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipos_empreendimentos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipos_empreendimentos_id_seq OWNER TO postgres;

--
-- Name: tipos_empreendimentos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipos_empreendimentos_id_seq OWNED BY public.tipos_empreendimentos.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    login character varying(20) NOT NULL,
    senha character varying(50) NOT NULL,
    id_statusregistro integer
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_seq OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: empreendimentos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empreendimentos ALTER COLUMN id SET DEFAULT nextval('public.empreendimentos_id_seq'::regclass);


--
-- Name: empreendimentos_usuarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empreendimentos_usuarios ALTER COLUMN id SET DEFAULT nextval('public.empreendimentos_usuarios_id_seq'::regclass);


--
-- Name: log_empreendimentos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.log_empreendimentos ALTER COLUMN id SET DEFAULT nextval('public.log_empreendimentos_id_seq'::regclass);


--
-- Name: status_registro id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_registro ALTER COLUMN id SET DEFAULT nextval('public.status_registro_id_seq'::regclass);


--
-- Name: tipos_empreendimentos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipos_empreendimentos ALTER COLUMN id SET DEFAULT nextval('public.tipos_empreendimentos_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: empreendimentos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.empreendimentos (id, cnpj, razao_social, id_statusregistro, id_tiposempreendimentos, buscardados, atualizarpage, tempambmax, tempambmin, tempambmedidor, umidambmax, umidambmin, emailnotificacao, notificar, editado, correntmin, correntmax) FROM stdin;
\.
COPY public.empreendimentos (id, cnpj, razao_social, id_statusregistro, id_tiposempreendimentos, buscardados, atualizarpage, tempambmax, tempambmin, tempambmedidor, umidambmax, umidambmin, emailnotificacao, notificar, editado, correntmin, correntmax) FROM '$$PATH$$/2879.dat';

--
-- Data for Name: empreendimentos_usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.empreendimentos_usuarios (id, id_usuario, id_empreendimentos) FROM stdin;
\.
COPY public.empreendimentos_usuarios (id, id_usuario, id_empreendimentos) FROM '$$PATH$$/2881.dat';

--
-- Data for Name: log_empreendimentos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.log_empreendimentos (id, id_empreendimento, datahorainclusao, temperatura, umidade) FROM stdin;
\.
COPY public.log_empreendimentos (id, id_empreendimento, datahorainclusao, temperatura, umidade) FROM '$$PATH$$/2883.dat';

--
-- Data for Name: status_registro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status_registro (id, descricao) FROM stdin;
\.
COPY public.status_registro (id, descricao) FROM '$$PATH$$/2885.dat';

--
-- Data for Name: tipos_empreendimentos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipos_empreendimentos (id, descricao) FROM stdin;
\.
COPY public.tipos_empreendimentos (id, descricao) FROM '$$PATH$$/2887.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (id, nome, login, senha, id_statusregistro) FROM stdin;
\.
COPY public.usuarios (id, nome, login, senha, id_statusregistro) FROM '$$PATH$$/2889.dat';

--
-- Name: empreendimentos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.empreendimentos_id_seq', 10, true);


--
-- Name: empreendimentos_usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.empreendimentos_usuarios_id_seq', 22, true);


--
-- Name: log_empreendimentos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.log_empreendimentos_id_seq', 1, false);


--
-- Name: status_registro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.status_registro_id_seq', 4, true);


--
-- Name: tipos_empreendimentos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipos_empreendimentos_id_seq', 2, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 5, true);


--
-- Name: empreendimentos empreendimentos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empreendimentos
    ADD CONSTRAINT empreendimentos_pkey PRIMARY KEY (id);


--
-- Name: empreendimentos_usuarios empreendimentos_usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empreendimentos_usuarios
    ADD CONSTRAINT empreendimentos_usuarios_pkey PRIMARY KEY (id);


--
-- Name: log_empreendimentos log_empreendimentos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.log_empreendimentos
    ADD CONSTRAINT log_empreendimentos_pkey PRIMARY KEY (id);


--
-- Name: status_registro status_registro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_registro
    ADD CONSTRAINT status_registro_pkey PRIMARY KEY (id);


--
-- Name: tipos_empreendimentos tipos_empreendimentos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipos_empreendimentos
    ADD CONSTRAINT tipos_empreendimentos_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: empreendimentos empreendimentos_id_statusregistro_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empreendimentos
    ADD CONSTRAINT empreendimentos_id_statusregistro_fkey FOREIGN KEY (id_statusregistro) REFERENCES public.status_registro(id);


--
-- Name: empreendimentos_usuarios empreendimentos_usuarios_id_empreendimentos_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empreendimentos_usuarios
    ADD CONSTRAINT empreendimentos_usuarios_id_empreendimentos_fkey FOREIGN KEY (id_empreendimentos) REFERENCES public.empreendimentos(id);


--
-- Name: empreendimentos_usuarios empreendimentos_usuarios_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empreendimentos_usuarios
    ADD CONSTRAINT empreendimentos_usuarios_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id);


--
-- Name: empreendimentos id_tiposempreendimentos; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empreendimentos
    ADD CONSTRAINT id_tiposempreendimentos FOREIGN KEY (id_tiposempreendimentos) REFERENCES public.tipos_empreendimentos(id);


--
-- Name: log_empreendimentos log_empreendimentos_id_empreendimento_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.log_empreendimentos
    ADD CONSTRAINT log_empreendimentos_id_empreendimento_fkey FOREIGN KEY (id_empreendimento) REFERENCES public.empreendimentos(id);


--
-- Name: usuarios usuarios_id_statusregistro_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_id_statusregistro_fkey FOREIGN KEY (id_statusregistro) REFERENCES public.status_registro(id);


--
-- PostgreSQL database dump complete
--

